﻿namespace EOM_v3_M
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.dgvSelect = new System.Windows.Forms.DataGridView();
            this.Column5 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.select_eo_contents = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.Column16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.dgvMain = new System.Windows.Forms.DataGridView();
            this.dataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.guest_eo_contents = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column15 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.Column18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblUserName = new System.Windows.Forms.Label();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.cbbLineName = new Guna.UI2.WinForms.Guna2ComboBox();
            this.cbbProductName = new Guna.UI2.WinForms.Guna2ComboBox();
            this.BtnProductUpdate = new Guna.UI2.WinForms.Guna2Button();
            this.guna2DragControl1 = new Guna.UI2.WinForms.Guna2DragControl(this.components);
            this.lblFormTitle = new System.Windows.Forms.Label();
            this.btnProductSearch = new Guna.UI2.WinForms.Guna2Button();
            this.btnProductAdd = new Guna.UI2.WinForms.Guna2Button();
            this.btnProductDelete = new Guna.UI2.WinForms.Guna2Button();
            this.pnTitle = new System.Windows.Forms.Panel();
            this.txtMenuAllSearch = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2ControlBox3 = new Guna.UI2.WinForms.Guna2ControlBox();
            this.guna2ControlBox2 = new Guna.UI2.WinForms.Guna2ControlBox();
            this.ctbMin = new Guna.UI2.WinForms.Guna2ControlBox();
            this.lblTopDeco = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.파일ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.로그인ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.로그아웃ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.사용자등록ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.업데이트ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.종료ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.도움말HToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.업데이트내역ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.실험실ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnShipmentChange = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.lblLine = new System.Windows.Forms.Label();
            this.guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            this.lblProduct = new System.Windows.Forms.Label();
            this.guna2Panel3 = new Guna.UI2.WinForms.Guna2Panel();
            this.lblDB = new System.Windows.Forms.Label();
            this.guna2Panel4 = new Guna.UI2.WinForms.Guna2Panel();
            this.lblDBUpTime = new System.Windows.Forms.Label();
            this.pnShipmentView = new Guna.UI2.WinForms.Guna2Panel();
            this.lblShipmentView = new System.Windows.Forms.Label();
            this.guna2BorderlessForm1 = new Guna.UI2.WinForms.Guna2BorderlessForm(this.components);
            this.btnShipmentMaster = new Guna.UI2.WinForms.Guna2Button();
            this.pnFpiCheck = new Guna.UI2.WinForms.Guna2Panel();
            this.lblFpiCheck = new System.Windows.Forms.Label();
            this.grpShipment = new Guna.UI2.WinForms.Guna2GroupBox();
            this.grpProduct = new Guna.UI2.WinForms.Guna2GroupBox();
            this.grpEOCheck = new Guna.UI2.WinForms.Guna2GroupBox();
            this.btnNewEO = new Guna.UI2.WinForms.Guna2Button();
            this.btnEOPCB = new Guna.UI2.WinForms.Guna2Button();
            this.btnEOContents = new Guna.UI2.WinForms.Guna2Button();
            this.grpDgvFilter = new Guna.UI2.WinForms.Guna2GroupBox();
            this.guna2CheckBox1 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.pnMain = new Guna.UI2.WinForms.Guna2Panel();
            this.pnSelect = new Guna.UI2.WinForms.Guna2Panel();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSelect)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnTitle.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.guna2Panel1.SuspendLayout();
            this.guna2Panel2.SuspendLayout();
            this.guna2Panel3.SuspendLayout();
            this.guna2Panel4.SuspendLayout();
            this.pnShipmentView.SuspendLayout();
            this.pnFpiCheck.SuspendLayout();
            this.grpShipment.SuspendLayout();
            this.grpProduct.SuspendLayout();
            this.grpEOCheck.SuspendLayout();
            this.grpDgvFilter.SuspendLayout();
            this.pnMain.SuspendLayout();
            this.pnSelect.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvSelect
            // 
            this.dgvSelect.AllowUserToAddRows = false;
            this.dgvSelect.AllowUserToDeleteRows = false;
            this.dgvSelect.AllowUserToResizeColumns = false;
            this.dgvSelect.AllowUserToResizeRows = false;
            this.dgvSelect.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSelect.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvSelect.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSelect.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column5,
            this.Column12,
            this.Column6,
            this.Column2,
            this.Column7,
            this.select_eo_contents,
            this.Column23,
            this.Column4,
            this.Column10,
            this.Column8,
            this.Column9,
            this.Column1,
            this.Column14,
            this.Column16,
            this.Column17,
            this.Column20,
            this.Column24});
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle17.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvSelect.DefaultCellStyle = dataGridViewCellStyle17;
            this.dgvSelect.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvSelect.EnableHeadersVisualStyles = false;
            this.dgvSelect.Location = new System.Drawing.Point(0, 0);
            this.dgvSelect.MultiSelect = false;
            this.dgvSelect.Name = "dgvSelect";
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSelect.RowHeadersDefaultCellStyle = dataGridViewCellStyle18;
            this.dgvSelect.RowHeadersVisible = false;
            this.dgvSelect.RowTemplate.Height = 23;
            this.dgvSelect.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvSelect.Size = new System.Drawing.Size(298, 242);
            this.dgvSelect.TabIndex = 0;
            this.dgvSelect.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVMHTDataView_CellContentClick);
            this.dgvSelect.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.MouseRightClickView_CellMouseClick);
            this.dgvSelect.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.SeparateBackColor_CellPainting);
            this.dgvSelect.VisibleChanged += new System.EventHandler(this.dataGridView1_VisibleChanged);
            // 
            // Column5
            // 
            this.Column5.HeaderText = "";
            this.Column5.Name = "Column5";
            this.Column5.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column5.Width = 30;
            // 
            // Column12
            // 
            this.Column12.HeaderText = "품번";
            this.Column12.Name = "Column12";
            this.Column12.ReadOnly = true;
            this.Column12.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column12.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column12.Visible = false;
            // 
            // Column6
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column6.DefaultCellStyle = dataGridViewCellStyle2;
            this.Column6.HeaderText = "차종";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            this.Column6.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Column2
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column2.DefaultCellStyle = dataGridViewCellStyle3;
            this.Column2.HeaderText = "고객사 EO";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column2.Width = 90;
            // 
            // Column7
            // 
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column7.DefaultCellStyle = dataGridViewCellStyle4;
            this.Column7.HeaderText = "모비스 EO";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            this.Column7.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column7.Width = 90;
            // 
            // select_eo_contents
            // 
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.select_eo_contents.DefaultCellStyle = dataGridViewCellStyle5;
            this.select_eo_contents.HeaderText = "EO 내용";
            this.select_eo_contents.Name = "select_eo_contents";
            this.select_eo_contents.ReadOnly = true;
            this.select_eo_contents.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.select_eo_contents.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.select_eo_contents.Width = 360;
            // 
            // Column23
            // 
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column23.DefaultCellStyle = dataGridViewCellStyle6;
            this.Column23.HeaderText = "스티커 색상";
            this.Column23.Name = "Column23";
            this.Column23.ReadOnly = true;
            this.Column23.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column23.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column23.Width = 50;
            // 
            // Column4
            // 
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column4.DefaultCellStyle = dataGridViewCellStyle7;
            this.Column4.HeaderText = "적용일";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column4.Width = 130;
            // 
            // Column10
            // 
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column10.DefaultCellStyle = dataGridViewCellStyle8;
            this.Column10.HeaderText = "종료일";
            this.Column10.Name = "Column10";
            this.Column10.ReadOnly = true;
            this.Column10.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column10.Width = 130;
            // 
            // Column8
            // 
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column8.DefaultCellStyle = dataGridViewCellStyle9;
            this.Column8.HeaderText = "등록자";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            this.Column8.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column8.Width = 80;
            // 
            // Column9
            // 
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column9.DefaultCellStyle = dataGridViewCellStyle10;
            this.Column9.HeaderText = "타입";
            this.Column9.Name = "Column9";
            this.Column9.ReadOnly = true;
            this.Column9.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column9.Width = 70;
            // 
            // Column1
            // 
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column1.DefaultCellStyle = dataGridViewCellStyle11;
            this.Column1.HeaderText = "출하지";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column1.Width = 60;
            // 
            // Column14
            // 
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column14.DefaultCellStyle = dataGridViewCellStyle12;
            this.Column14.HeaderText = "근거자료";
            this.Column14.Name = "Column14";
            this.Column14.ReadOnly = true;
            this.Column14.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column14.Width = 60;
            // 
            // Column16
            // 
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column16.DefaultCellStyle = dataGridViewCellStyle13;
            this.Column16.HeaderText = "MAIN PCB";
            this.Column16.Name = "Column16";
            this.Column16.ReadOnly = true;
            this.Column16.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column16.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Column17
            // 
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column17.DefaultCellStyle = dataGridViewCellStyle14;
            this.Column17.HeaderText = "SUB PCB";
            this.Column17.Name = "Column17";
            this.Column17.ReadOnly = true;
            this.Column17.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column17.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Column20
            // 
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column20.DefaultCellStyle = dataGridViewCellStyle15;
            this.Column20.HeaderText = "EO 구분";
            this.Column20.Name = "Column20";
            this.Column20.ReadOnly = true;
            this.Column20.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column20.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Column24
            // 
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column24.DefaultCellStyle = dataGridViewCellStyle16;
            this.Column24.HeaderText = "적용 오더";
            this.Column24.Name = "Column24";
            this.Column24.ReadOnly = true;
            this.Column24.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column24.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // timer1
            // 
            this.timer1.Interval = 3000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // dgvMain
            // 
            this.dgvMain.AllowUserToAddRows = false;
            this.dgvMain.AllowUserToDeleteRows = false;
            this.dgvMain.AllowUserToResizeColumns = false;
            this.dgvMain.AllowUserToResizeRows = false;
            this.dgvMain.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle19.BackColor = System.Drawing.Color.Wheat;
            dataGridViewCellStyle19.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle19.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvMain.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle19;
            this.dgvMain.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMain.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewCheckBoxColumn1,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.guest_eo_contents,
            this.Column22,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.Column13,
            this.dataGridViewTextBoxColumn9,
            this.Column11,
            this.Column15,
            this.Column18,
            this.Column19,
            this.Column21,
            this.Column25});
            dataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle36.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle36.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle36.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle36.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle36.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle36.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvMain.DefaultCellStyle = dataGridViewCellStyle36;
            this.dgvMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvMain.EnableHeadersVisualStyles = false;
            this.dgvMain.Location = new System.Drawing.Point(0, 0);
            this.dgvMain.MultiSelect = false;
            this.dgvMain.Name = "dgvMain";
            this.dgvMain.ReadOnly = true;
            dataGridViewCellStyle37.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle37.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle37.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle37.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle37.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle37.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle37.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvMain.RowHeadersDefaultCellStyle = dataGridViewCellStyle37;
            this.dgvMain.RowHeadersVisible = false;
            this.dgvMain.RowTemplate.Height = 23;
            this.dgvMain.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvMain.Size = new System.Drawing.Size(320, 242);
            this.dgvMain.TabIndex = 48;
            this.dgvMain.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVMHTDataView_CellContentClick);
            this.dgvMain.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.MouseRightClickView_CellMouseClick);
            this.dgvMain.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.SeparateBackColor_CellPainting);
            // 
            // dataGridViewCheckBoxColumn1
            // 
            this.dataGridViewCheckBoxColumn1.HeaderText = "";
            this.dataGridViewCheckBoxColumn1.MinimumWidth = 30;
            this.dataGridViewCheckBoxColumn1.Name = "dataGridViewCheckBoxColumn1";
            this.dataGridViewCheckBoxColumn1.ReadOnly = true;
            this.dataGridViewCheckBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewCheckBoxColumn1.Visible = false;
            this.dataGridViewCheckBoxColumn1.Width = 30;
            // 
            // dataGridViewTextBoxColumn5
            // 
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn5.DefaultCellStyle = dataGridViewCellStyle20;
            this.dataGridViewTextBoxColumn5.HeaderText = "품번";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn1
            // 
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle21;
            this.dataGridViewTextBoxColumn1.HeaderText = "차종";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn2
            // 
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn2.DefaultCellStyle = dataGridViewCellStyle22;
            this.dataGridViewTextBoxColumn2.HeaderText = "고객사 EO";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn2.Width = 90;
            // 
            // dataGridViewTextBoxColumn3
            // 
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle23;
            this.dataGridViewTextBoxColumn3.HeaderText = "모비스 EO";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn3.Width = 90;
            // 
            // guest_eo_contents
            // 
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.guest_eo_contents.DefaultCellStyle = dataGridViewCellStyle24;
            this.guest_eo_contents.HeaderText = "EO 내용";
            this.guest_eo_contents.Name = "guest_eo_contents";
            this.guest_eo_contents.ReadOnly = true;
            this.guest_eo_contents.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.guest_eo_contents.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.guest_eo_contents.Width = 360;
            // 
            // Column22
            // 
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column22.DefaultCellStyle = dataGridViewCellStyle25;
            this.Column22.HeaderText = "스티커 색상";
            this.Column22.Name = "Column22";
            this.Column22.ReadOnly = true;
            this.Column22.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column22.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column22.Width = 50;
            // 
            // dataGridViewTextBoxColumn6
            // 
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn6.DefaultCellStyle = dataGridViewCellStyle26;
            this.dataGridViewTextBoxColumn6.HeaderText = "적용일";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn6.Width = 73;
            // 
            // dataGridViewTextBoxColumn7
            // 
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn7.DefaultCellStyle = dataGridViewCellStyle27;
            this.dataGridViewTextBoxColumn7.HeaderText = "종료일";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn7.Width = 130;
            // 
            // Column13
            // 
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column13.DefaultCellStyle = dataGridViewCellStyle28;
            this.Column13.HeaderText = "등록자";
            this.Column13.Name = "Column13";
            this.Column13.ReadOnly = true;
            this.Column13.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column13.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column13.Width = 80;
            // 
            // dataGridViewTextBoxColumn9
            // 
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn9.DefaultCellStyle = dataGridViewCellStyle29;
            this.dataGridViewTextBoxColumn9.HeaderText = "타입";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn9.Width = 70;
            // 
            // Column11
            // 
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column11.DefaultCellStyle = dataGridViewCellStyle30;
            this.Column11.HeaderText = "출하지";
            this.Column11.Name = "Column11";
            this.Column11.ReadOnly = true;
            this.Column11.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column11.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column11.Width = 60;
            // 
            // Column15
            // 
            dataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column15.DefaultCellStyle = dataGridViewCellStyle31;
            this.Column15.HeaderText = "근거자료";
            this.Column15.Name = "Column15";
            this.Column15.ReadOnly = true;
            this.Column15.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column15.Width = 60;
            // 
            // Column18
            // 
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column18.DefaultCellStyle = dataGridViewCellStyle32;
            this.Column18.HeaderText = "MAIN PCB";
            this.Column18.Name = "Column18";
            this.Column18.ReadOnly = true;
            this.Column18.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column18.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column18.Width = 73;
            // 
            // Column19
            // 
            dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column19.DefaultCellStyle = dataGridViewCellStyle33;
            this.Column19.HeaderText = "SUB PCB";
            this.Column19.Name = "Column19";
            this.Column19.ReadOnly = true;
            this.Column19.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column19.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column19.Width = 74;
            // 
            // Column21
            // 
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column21.DefaultCellStyle = dataGridViewCellStyle34;
            this.Column21.HeaderText = "EO 구분";
            this.Column21.Name = "Column21";
            this.Column21.ReadOnly = true;
            this.Column21.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column21.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column21.Width = 73;
            // 
            // Column25
            // 
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column25.DefaultCellStyle = dataGridViewCellStyle35;
            this.Column25.HeaderText = "적용 오더";
            this.Column25.Name = "Column25";
            this.Column25.ReadOnly = true;
            this.Column25.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column25.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column25.Width = 74;
            // 
            // lblUserName
            // 
            this.lblUserName.Location = new System.Drawing.Point(1036, 40);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Size = new System.Drawing.Size(233, 24);
            this.lblUserName.TabIndex = 50;
            this.lblUserName.Text = "GUEST님 로그인";
            this.lblUserName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // timer2
            // 
            this.timer2.Interval = 3000;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.InitialImage = null;
            this.pictureBox1.Location = new System.Drawing.Point(328, 156);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(29, 29);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 53;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            this.pictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseDown);
            this.pictureBox1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseUp);
            // 
            // timer3
            // 
            this.timer3.Interval = 600000;
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // cbbLineName
            // 
            this.cbbLineName.BackColor = System.Drawing.Color.Transparent;
            this.cbbLineName.BorderColor = System.Drawing.SystemColors.ControlDark;
            this.cbbLineName.BorderRadius = 8;
            this.cbbLineName.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cbbLineName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbLineName.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.cbbLineName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.cbbLineName.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.cbbLineName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cbbLineName.ItemHeight = 23;
            this.cbbLineName.Items.AddRange(new object[] {
            "D-오디오 조립"});
            this.cbbLineName.Location = new System.Drawing.Point(117, 82);
            this.cbbLineName.Name = "cbbLineName";
            this.cbbLineName.Size = new System.Drawing.Size(205, 29);
            this.cbbLineName.TabIndex = 57;
            this.cbbLineName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.cbbLineName.SelectedIndexChanged += new System.EventHandler(this.cbbLineName_SelectedIndexChanged);
            // 
            // cbbProductName
            // 
            this.cbbProductName.BackColor = System.Drawing.Color.Transparent;
            this.cbbProductName.BorderColor = System.Drawing.SystemColors.ControlDark;
            this.cbbProductName.BorderRadius = 8;
            this.cbbProductName.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cbbProductName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbProductName.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.cbbProductName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.cbbProductName.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.cbbProductName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cbbProductName.ItemHeight = 23;
            this.cbbProductName.Items.AddRange(new object[] {
            "D-오디오 조립"});
            this.cbbProductName.Location = new System.Drawing.Point(117, 119);
            this.cbbProductName.Name = "cbbProductName";
            this.cbbProductName.Size = new System.Drawing.Size(205, 29);
            this.cbbProductName.TabIndex = 58;
            this.cbbProductName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.cbbProductName.SelectedIndexChanged += new System.EventHandler(this.cbbProductName_SelectedIndexChanged);
            // 
            // BtnProductUpdate
            // 
            this.BtnProductUpdate.BackColor = System.Drawing.Color.Transparent;
            this.BtnProductUpdate.BorderColor = System.Drawing.Color.Silver;
            this.BtnProductUpdate.BorderRadius = 8;
            this.BtnProductUpdate.BorderThickness = 1;
            this.BtnProductUpdate.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.BtnProductUpdate.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.BtnProductUpdate.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.BtnProductUpdate.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.BtnProductUpdate.FillColor = System.Drawing.SystemColors.ControlLight;
            this.BtnProductUpdate.FocusedColor = System.Drawing.SystemColors.ControlDark;
            this.BtnProductUpdate.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.BtnProductUpdate.ForeColor = System.Drawing.Color.Black;
            this.BtnProductUpdate.Location = new System.Drawing.Point(328, 82);
            this.BtnProductUpdate.Name = "BtnProductUpdate";
            this.BtnProductUpdate.Size = new System.Drawing.Size(60, 29);
            this.BtnProductUpdate.TabIndex = 60;
            this.BtnProductUpdate.Text = "갱신";
            this.BtnProductUpdate.Click += new System.EventHandler(this.BtnProductUpdate_Click);
            // 
            // guna2DragControl1
            // 
            this.guna2DragControl1.DockIndicatorTransparencyValue = 0.6D;
            this.guna2DragControl1.TargetControl = this.lblFormTitle;
            this.guna2DragControl1.UseTransparentDrag = true;
            // 
            // lblFormTitle
            // 
            this.lblFormTitle.BackColor = System.Drawing.Color.White;
            this.lblFormTitle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblFormTitle.Font = new System.Drawing.Font("Segoe UI Semibold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFormTitle.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblFormTitle.Location = new System.Drawing.Point(0, 5);
            this.lblFormTitle.Name = "lblFormTitle";
            this.lblFormTitle.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.lblFormTitle.Size = new System.Drawing.Size(1280, 45);
            this.lblFormTitle.TabIndex = 79;
            this.lblFormTitle.Text = "Engineer Order Manager v3.1 (멀티 통합)";
            this.lblFormTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblFormTitle.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.lblFormTitle_MouseDoubleClick);
            // 
            // btnProductSearch
            // 
            this.btnProductSearch.BackColor = System.Drawing.Color.Transparent;
            this.btnProductSearch.BorderColor = System.Drawing.Color.Silver;
            this.btnProductSearch.BorderRadius = 8;
            this.btnProductSearch.BorderThickness = 1;
            this.btnProductSearch.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnProductSearch.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnProductSearch.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnProductSearch.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnProductSearch.FillColor = System.Drawing.SystemColors.ControlLight;
            this.btnProductSearch.FocusedColor = System.Drawing.SystemColors.ControlDark;
            this.btnProductSearch.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnProductSearch.ForeColor = System.Drawing.Color.Black;
            this.btnProductSearch.Location = new System.Drawing.Point(9, 33);
            this.btnProductSearch.Name = "btnProductSearch";
            this.btnProductSearch.Size = new System.Drawing.Size(60, 29);
            this.btnProductSearch.TabIndex = 74;
            this.btnProductSearch.Text = "검색";
            this.btnProductSearch.Click += new System.EventHandler(this.btnProductSearch_Click);
            // 
            // btnProductAdd
            // 
            this.btnProductAdd.BackColor = System.Drawing.Color.Transparent;
            this.btnProductAdd.BorderColor = System.Drawing.Color.Silver;
            this.btnProductAdd.BorderRadius = 8;
            this.btnProductAdd.BorderThickness = 1;
            this.btnProductAdd.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnProductAdd.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnProductAdd.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnProductAdd.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnProductAdd.FillColor = System.Drawing.SystemColors.ControlLight;
            this.btnProductAdd.FocusedColor = System.Drawing.SystemColors.ControlDark;
            this.btnProductAdd.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnProductAdd.ForeColor = System.Drawing.Color.Black;
            this.btnProductAdd.Location = new System.Drawing.Point(75, 33);
            this.btnProductAdd.Name = "btnProductAdd";
            this.btnProductAdd.Size = new System.Drawing.Size(60, 29);
            this.btnProductAdd.TabIndex = 75;
            this.btnProductAdd.Text = "추가";
            this.btnProductAdd.Click += new System.EventHandler(this.btnProductAdd_Click);
            // 
            // btnProductDelete
            // 
            this.btnProductDelete.BackColor = System.Drawing.Color.Transparent;
            this.btnProductDelete.BorderColor = System.Drawing.Color.Silver;
            this.btnProductDelete.BorderRadius = 8;
            this.btnProductDelete.BorderThickness = 1;
            this.btnProductDelete.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnProductDelete.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnProductDelete.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnProductDelete.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnProductDelete.FillColor = System.Drawing.SystemColors.ControlLight;
            this.btnProductDelete.FocusedColor = System.Drawing.SystemColors.ControlDark;
            this.btnProductDelete.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnProductDelete.ForeColor = System.Drawing.Color.Black;
            this.btnProductDelete.Location = new System.Drawing.Point(141, 33);
            this.btnProductDelete.Name = "btnProductDelete";
            this.btnProductDelete.Size = new System.Drawing.Size(60, 29);
            this.btnProductDelete.TabIndex = 76;
            this.btnProductDelete.Text = "삭제";
            this.btnProductDelete.Click += new System.EventHandler(this.btnProductDelete_Click);
            // 
            // pnTitle
            // 
            this.pnTitle.Controls.Add(this.txtMenuAllSearch);
            this.pnTitle.Controls.Add(this.guna2ControlBox3);
            this.pnTitle.Controls.Add(this.guna2ControlBox2);
            this.pnTitle.Controls.Add(this.ctbMin);
            this.pnTitle.Controls.Add(this.lblFormTitle);
            this.pnTitle.Controls.Add(this.lblTopDeco);
            this.pnTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnTitle.Location = new System.Drawing.Point(0, 0);
            this.pnTitle.Name = "pnTitle";
            this.pnTitle.Size = new System.Drawing.Size(1280, 50);
            this.pnTitle.TabIndex = 82;
            // 
            // txtMenuAllSearch
            // 
            this.txtMenuAllSearch.BackColor = System.Drawing.Color.White;
            this.txtMenuAllSearch.BorderRadius = 8;
            this.txtMenuAllSearch.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtMenuAllSearch.DefaultText = "";
            this.txtMenuAllSearch.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtMenuAllSearch.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtMenuAllSearch.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtMenuAllSearch.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtMenuAllSearch.Enabled = false;
            this.txtMenuAllSearch.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtMenuAllSearch.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtMenuAllSearch.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtMenuAllSearch.IconLeftSize = new System.Drawing.Size(15, 15);
            this.txtMenuAllSearch.IconRight = ((System.Drawing.Image)(resources.GetObject("txtMenuAllSearch.IconRight")));
            this.txtMenuAllSearch.IconRightSize = new System.Drawing.Size(15, 15);
            this.txtMenuAllSearch.Location = new System.Drawing.Point(971, 8);
            this.txtMenuAllSearch.Name = "txtMenuAllSearch";
            this.txtMenuAllSearch.PasswordChar = '\0';
            this.txtMenuAllSearch.PlaceholderText = "";
            this.txtMenuAllSearch.SelectedText = "";
            this.txtMenuAllSearch.Size = new System.Drawing.Size(200, 23);
            this.txtMenuAllSearch.TabIndex = 82;
            // 
            // guna2ControlBox3
            // 
            this.guna2ControlBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ControlBox3.ControlBoxStyle = Guna.UI2.WinForms.Enums.ControlBoxStyle.Custom;
            this.guna2ControlBox3.FillColor = System.Drawing.Color.White;
            this.guna2ControlBox3.IconColor = System.Drawing.SystemColors.ControlDarkDark;
            this.guna2ControlBox3.Location = new System.Drawing.Point(1250, 6);
            this.guna2ControlBox3.Name = "guna2ControlBox3";
            this.guna2ControlBox3.Size = new System.Drawing.Size(30, 25);
            this.guna2ControlBox3.TabIndex = 85;
            // 
            // guna2ControlBox2
            // 
            this.guna2ControlBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ControlBox2.ControlBoxStyle = Guna.UI2.WinForms.Enums.ControlBoxStyle.Custom;
            this.guna2ControlBox2.ControlBoxType = Guna.UI2.WinForms.Enums.ControlBoxType.MaximizeBox;
            this.guna2ControlBox2.FillColor = System.Drawing.Color.White;
            this.guna2ControlBox2.IconColor = System.Drawing.SystemColors.ControlDarkDark;
            this.guna2ControlBox2.Location = new System.Drawing.Point(1219, 6);
            this.guna2ControlBox2.Name = "guna2ControlBox2";
            this.guna2ControlBox2.Size = new System.Drawing.Size(30, 25);
            this.guna2ControlBox2.TabIndex = 84;
            // 
            // ctbMin
            // 
            this.ctbMin.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ctbMin.ControlBoxStyle = Guna.UI2.WinForms.Enums.ControlBoxStyle.Custom;
            this.ctbMin.ControlBoxType = Guna.UI2.WinForms.Enums.ControlBoxType.MinimizeBox;
            this.ctbMin.FillColor = System.Drawing.Color.White;
            this.ctbMin.IconColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ctbMin.Location = new System.Drawing.Point(1188, 6);
            this.ctbMin.Name = "ctbMin";
            this.ctbMin.Size = new System.Drawing.Size(30, 25);
            this.ctbMin.TabIndex = 83;
            // 
            // lblTopDeco
            // 
            this.lblTopDeco.BackColor = System.Drawing.Color.DodgerBlue;
            this.lblTopDeco.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblTopDeco.Location = new System.Drawing.Point(0, 0);
            this.lblTopDeco.Name = "lblTopDeco";
            this.lblTopDeco.Size = new System.Drawing.Size(1280, 5);
            this.lblTopDeco.TabIndex = 1;
            this.lblTopDeco.Text = " ";
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.White;
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.파일ToolStripMenuItem,
            this.도움말HToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 50);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1280, 24);
            this.menuStrip1.TabIndex = 83;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // 파일ToolStripMenuItem
            // 
            this.파일ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.로그인ToolStripMenuItem,
            this.로그아웃ToolStripMenuItem,
            this.사용자등록ToolStripMenuItem,
            this.toolStripMenuItem1,
            this.업데이트ToolStripMenuItem,
            this.toolStripMenuItem2,
            this.종료ToolStripMenuItem});
            this.파일ToolStripMenuItem.Name = "파일ToolStripMenuItem";
            this.파일ToolStripMenuItem.Size = new System.Drawing.Size(57, 20);
            this.파일ToolStripMenuItem.Text = "파일(&F)";
            // 
            // 로그인ToolStripMenuItem
            // 
            this.로그인ToolStripMenuItem.Enabled = false;
            this.로그인ToolStripMenuItem.Name = "로그인ToolStripMenuItem";
            this.로그인ToolStripMenuItem.Size = new System.Drawing.Size(137, 22);
            this.로그인ToolStripMenuItem.Text = "로그인";
            this.로그인ToolStripMenuItem.Click += new System.EventHandler(this.로그인ToolStripMenuItem_Click);
            // 
            // 로그아웃ToolStripMenuItem
            // 
            this.로그아웃ToolStripMenuItem.Enabled = false;
            this.로그아웃ToolStripMenuItem.Name = "로그아웃ToolStripMenuItem";
            this.로그아웃ToolStripMenuItem.Size = new System.Drawing.Size(137, 22);
            this.로그아웃ToolStripMenuItem.Text = "로그아웃";
            this.로그아웃ToolStripMenuItem.Click += new System.EventHandler(this.로그아웃ToolStripMenuItem_Click);
            // 
            // 사용자등록ToolStripMenuItem
            // 
            this.사용자등록ToolStripMenuItem.Name = "사용자등록ToolStripMenuItem";
            this.사용자등록ToolStripMenuItem.Size = new System.Drawing.Size(137, 22);
            this.사용자등록ToolStripMenuItem.Text = "사용자 등록";
            this.사용자등록ToolStripMenuItem.Click += new System.EventHandler(this.사용자등록ToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(134, 6);
            // 
            // 업데이트ToolStripMenuItem
            // 
            this.업데이트ToolStripMenuItem.Name = "업데이트ToolStripMenuItem";
            this.업데이트ToolStripMenuItem.Size = new System.Drawing.Size(137, 22);
            this.업데이트ToolStripMenuItem.Text = "업데이트";
            this.업데이트ToolStripMenuItem.Click += new System.EventHandler(this.업데이트ToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(134, 6);
            // 
            // 종료ToolStripMenuItem
            // 
            this.종료ToolStripMenuItem.Name = "종료ToolStripMenuItem";
            this.종료ToolStripMenuItem.Size = new System.Drawing.Size(137, 22);
            this.종료ToolStripMenuItem.Text = "종료";
            this.종료ToolStripMenuItem.Click += new System.EventHandler(this.종료ToolStripMenuItem_Click);
            // 
            // 도움말HToolStripMenuItem
            // 
            this.도움말HToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.업데이트내역ToolStripMenuItem,
            this.실험실ToolStripMenuItem});
            this.도움말HToolStripMenuItem.Name = "도움말HToolStripMenuItem";
            this.도움말HToolStripMenuItem.Size = new System.Drawing.Size(72, 20);
            this.도움말HToolStripMenuItem.Text = "도움말(&H)";
            // 
            // 업데이트내역ToolStripMenuItem
            // 
            this.업데이트내역ToolStripMenuItem.Name = "업데이트내역ToolStripMenuItem";
            this.업데이트내역ToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.업데이트내역ToolStripMenuItem.Text = "업데이트 내역";
            this.업데이트내역ToolStripMenuItem.Click += new System.EventHandler(this.업데이트내역ToolStripMenuItem_Click);
            // 
            // 실험실ToolStripMenuItem
            // 
            this.실험실ToolStripMenuItem.Name = "실험실ToolStripMenuItem";
            this.실험실ToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.실험실ToolStripMenuItem.Text = "실험실";
            this.실험실ToolStripMenuItem.Click += new System.EventHandler(this.실험실ToolStripMenuItem_Click);
            // 
            // btnShipmentChange
            // 
            this.btnShipmentChange.BackColor = System.Drawing.Color.Transparent;
            this.btnShipmentChange.BorderColor = System.Drawing.Color.Silver;
            this.btnShipmentChange.BorderRadius = 8;
            this.btnShipmentChange.BorderThickness = 1;
            this.btnShipmentChange.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnShipmentChange.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnShipmentChange.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnShipmentChange.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnShipmentChange.FillColor = System.Drawing.SystemColors.ControlLight;
            this.btnShipmentChange.FocusedColor = System.Drawing.SystemColors.ControlDark;
            this.btnShipmentChange.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnShipmentChange.ForeColor = System.Drawing.Color.Black;
            this.btnShipmentChange.Location = new System.Drawing.Point(141, 33);
            this.btnShipmentChange.Name = "btnShipmentChange";
            this.btnShipmentChange.Size = new System.Drawing.Size(60, 29);
            this.btnShipmentChange.TabIndex = 73;
            this.btnShipmentChange.Text = "변경";
            this.btnShipmentChange.Click += new System.EventHandler(this.btnShipmentChange_Click);
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.BorderColor = System.Drawing.SystemColors.ControlDarkDark;
            this.guna2Panel1.BorderRadius = 10;
            this.guna2Panel1.BorderThickness = 1;
            this.guna2Panel1.Controls.Add(this.lblLine);
            this.guna2Panel1.CustomizableEdges.BottomLeft = false;
            this.guna2Panel1.CustomizableEdges.TopLeft = false;
            this.guna2Panel1.FillColor = System.Drawing.SystemColors.ControlDarkDark;
            this.guna2Panel1.Location = new System.Drawing.Point(11, 82);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.Size = new System.Drawing.Size(100, 29);
            this.guna2Panel1.TabIndex = 84;
            // 
            // lblLine
            // 
            this.lblLine.BackColor = System.Drawing.Color.Transparent;
            this.lblLine.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblLine.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLine.ForeColor = System.Drawing.Color.White;
            this.lblLine.Location = new System.Drawing.Point(0, 0);
            this.lblLine.Name = "lblLine";
            this.lblLine.Size = new System.Drawing.Size(100, 29);
            this.lblLine.TabIndex = 0;
            this.lblLine.Text = "라인";
            this.lblLine.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblLine.Click += new System.EventHandler(this.lblLine_Click);
            // 
            // guna2Panel2
            // 
            this.guna2Panel2.BorderColor = System.Drawing.SystemColors.ControlDarkDark;
            this.guna2Panel2.BorderRadius = 8;
            this.guna2Panel2.BorderThickness = 1;
            this.guna2Panel2.Controls.Add(this.lblProduct);
            this.guna2Panel2.CustomizableEdges.BottomLeft = false;
            this.guna2Panel2.CustomizableEdges.TopLeft = false;
            this.guna2Panel2.FillColor = System.Drawing.SystemColors.ControlDarkDark;
            this.guna2Panel2.Location = new System.Drawing.Point(11, 119);
            this.guna2Panel2.Name = "guna2Panel2";
            this.guna2Panel2.Size = new System.Drawing.Size(100, 29);
            this.guna2Panel2.TabIndex = 85;
            // 
            // lblProduct
            // 
            this.lblProduct.BackColor = System.Drawing.Color.Transparent;
            this.lblProduct.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblProduct.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProduct.ForeColor = System.Drawing.Color.White;
            this.lblProduct.Location = new System.Drawing.Point(0, 0);
            this.lblProduct.Name = "lblProduct";
            this.lblProduct.Size = new System.Drawing.Size(100, 29);
            this.lblProduct.TabIndex = 0;
            this.lblProduct.Text = "품번";
            this.lblProduct.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // guna2Panel3
            // 
            this.guna2Panel3.BorderColor = System.Drawing.SystemColors.ControlDarkDark;
            this.guna2Panel3.BorderRadius = 8;
            this.guna2Panel3.BorderThickness = 1;
            this.guna2Panel3.Controls.Add(this.lblDB);
            this.guna2Panel3.CustomizableEdges.BottomLeft = false;
            this.guna2Panel3.CustomizableEdges.TopLeft = false;
            this.guna2Panel3.FillColor = System.Drawing.SystemColors.ControlDarkDark;
            this.guna2Panel3.Location = new System.Drawing.Point(11, 156);
            this.guna2Panel3.Name = "guna2Panel3";
            this.guna2Panel3.Size = new System.Drawing.Size(100, 29);
            this.guna2Panel3.TabIndex = 86;
            // 
            // lblDB
            // 
            this.lblDB.BackColor = System.Drawing.Color.Transparent;
            this.lblDB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDB.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDB.ForeColor = System.Drawing.Color.White;
            this.lblDB.Location = new System.Drawing.Point(0, 0);
            this.lblDB.Name = "lblDB";
            this.lblDB.Size = new System.Drawing.Size(100, 29);
            this.lblDB.TabIndex = 0;
            this.lblDB.Text = "갱신 시간";
            this.lblDB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // guna2Panel4
            // 
            this.guna2Panel4.BorderColor = System.Drawing.SystemColors.ControlDark;
            this.guna2Panel4.BorderRadius = 8;
            this.guna2Panel4.BorderThickness = 1;
            this.guna2Panel4.Controls.Add(this.lblDBUpTime);
            this.guna2Panel4.FillColor = System.Drawing.Color.Gainsboro;
            this.guna2Panel4.Location = new System.Drawing.Point(117, 156);
            this.guna2Panel4.Name = "guna2Panel4";
            this.guna2Panel4.Size = new System.Drawing.Size(205, 29);
            this.guna2Panel4.TabIndex = 87;
            // 
            // lblDBUpTime
            // 
            this.lblDBUpTime.BackColor = System.Drawing.Color.Transparent;
            this.lblDBUpTime.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDBUpTime.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblDBUpTime.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.lblDBUpTime.Location = new System.Drawing.Point(0, 0);
            this.lblDBUpTime.Name = "lblDBUpTime";
            this.lblDBUpTime.Size = new System.Drawing.Size(205, 29);
            this.lblDBUpTime.TabIndex = 0;
            this.lblDBUpTime.Text = "-";
            this.lblDBUpTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnShipmentView
            // 
            this.pnShipmentView.BorderColor = System.Drawing.SystemColors.ControlDark;
            this.pnShipmentView.BorderRadius = 8;
            this.pnShipmentView.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.pnShipmentView.BorderThickness = 1;
            this.pnShipmentView.Controls.Add(this.lblShipmentView);
            this.pnShipmentView.FillColor = System.Drawing.Color.White;
            this.pnShipmentView.Location = new System.Drawing.Point(9, 33);
            this.pnShipmentView.Name = "pnShipmentView";
            this.pnShipmentView.Size = new System.Drawing.Size(60, 29);
            this.pnShipmentView.TabIndex = 88;
            // 
            // lblShipmentView
            // 
            this.lblShipmentView.BackColor = System.Drawing.Color.Transparent;
            this.lblShipmentView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblShipmentView.Font = new System.Drawing.Font("현대하모니 B", 15.75F, System.Drawing.FontStyle.Bold);
            this.lblShipmentView.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lblShipmentView.Location = new System.Drawing.Point(0, 0);
            this.lblShipmentView.Margin = new System.Windows.Forms.Padding(0);
            this.lblShipmentView.Name = "lblShipmentView";
            this.lblShipmentView.Padding = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.lblShipmentView.Size = new System.Drawing.Size(60, 29);
            this.lblShipmentView.TabIndex = 0;
            this.lblShipmentView.Text = "CKD";
            this.lblShipmentView.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // guna2BorderlessForm1
            // 
            this.guna2BorderlessForm1.ContainerControl = this;
            this.guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6D;
            this.guna2BorderlessForm1.TransparentWhileDrag = true;
            // 
            // btnShipmentMaster
            // 
            this.btnShipmentMaster.BackColor = System.Drawing.Color.Transparent;
            this.btnShipmentMaster.BorderColor = System.Drawing.Color.Silver;
            this.btnShipmentMaster.BorderRadius = 8;
            this.btnShipmentMaster.BorderThickness = 1;
            this.btnShipmentMaster.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnShipmentMaster.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnShipmentMaster.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnShipmentMaster.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnShipmentMaster.Enabled = false;
            this.btnShipmentMaster.FillColor = System.Drawing.SystemColors.ControlLight;
            this.btnShipmentMaster.FocusedColor = System.Drawing.SystemColors.ControlDark;
            this.btnShipmentMaster.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnShipmentMaster.ForeColor = System.Drawing.Color.Black;
            this.btnShipmentMaster.Location = new System.Drawing.Point(75, 33);
            this.btnShipmentMaster.Name = "btnShipmentMaster";
            this.btnShipmentMaster.Size = new System.Drawing.Size(60, 29);
            this.btnShipmentMaster.TabIndex = 90;
            this.btnShipmentMaster.Text = "등록";
            this.btnShipmentMaster.Click += new System.EventHandler(this.btnShipmentMaster_Click);
            // 
            // pnFpiCheck
            // 
            this.pnFpiCheck.BorderColor = System.Drawing.SystemColors.ControlDark;
            this.pnFpiCheck.BorderRadius = 8;
            this.pnFpiCheck.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.pnFpiCheck.BorderThickness = 1;
            this.pnFpiCheck.Controls.Add(this.lblFpiCheck);
            this.pnFpiCheck.FillColor = System.Drawing.Color.White;
            this.pnFpiCheck.Location = new System.Drawing.Point(328, 119);
            this.pnFpiCheck.Name = "pnFpiCheck";
            this.pnFpiCheck.Size = new System.Drawing.Size(60, 29);
            this.pnFpiCheck.TabIndex = 89;
            // 
            // lblFpiCheck
            // 
            this.lblFpiCheck.BackColor = System.Drawing.Color.Transparent;
            this.lblFpiCheck.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblFpiCheck.Font = new System.Drawing.Font("현대하모니 B", 10F);
            this.lblFpiCheck.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblFpiCheck.Location = new System.Drawing.Point(0, 0);
            this.lblFpiCheck.Margin = new System.Windows.Forms.Padding(0);
            this.lblFpiCheck.Name = "lblFpiCheck";
            this.lblFpiCheck.Size = new System.Drawing.Size(60, 29);
            this.lblFpiCheck.TabIndex = 0;
            this.lblFpiCheck.Text = "미등록";
            this.lblFpiCheck.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblFpiCheck.Click += new System.EventHandler(this.lblFpiCheck_Click);
            // 
            // grpShipment
            // 
            this.grpShipment.BorderRadius = 8;
            this.grpShipment.Controls.Add(this.pnShipmentView);
            this.grpShipment.Controls.Add(this.btnShipmentMaster);
            this.grpShipment.Controls.Add(this.btnShipmentChange);
            this.grpShipment.CustomBorderColor = System.Drawing.SystemColors.ActiveCaption;
            this.grpShipment.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.grpShipment.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.grpShipment.ForeColor = System.Drawing.Color.Black;
            this.grpShipment.Location = new System.Drawing.Point(628, 115);
            this.grpShipment.Name = "grpShipment";
            this.grpShipment.Size = new System.Drawing.Size(210, 70);
            this.grpShipment.TabIndex = 92;
            this.grpShipment.Text = "출하지";
            // 
            // grpProduct
            // 
            this.grpProduct.BorderRadius = 8;
            this.grpProduct.Controls.Add(this.btnProductSearch);
            this.grpProduct.Controls.Add(this.btnProductAdd);
            this.grpProduct.Controls.Add(this.btnProductDelete);
            this.grpProduct.CustomBorderColor = System.Drawing.Color.White;
            this.grpProduct.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.grpProduct.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.grpProduct.ForeColor = System.Drawing.Color.Black;
            this.grpProduct.Location = new System.Drawing.Point(1060, 115);
            this.grpProduct.Name = "grpProduct";
            this.grpProduct.Size = new System.Drawing.Size(210, 70);
            this.grpProduct.TabIndex = 93;
            this.grpProduct.Text = "품번";
            // 
            // grpEOCheck
            // 
            this.grpEOCheck.BorderRadius = 8;
            this.grpEOCheck.Controls.Add(this.btnNewEO);
            this.grpEOCheck.Controls.Add(this.btnEOPCB);
            this.grpEOCheck.Controls.Add(this.btnEOContents);
            this.grpEOCheck.CustomBorderColor = System.Drawing.SystemColors.ActiveCaption;
            this.grpEOCheck.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.grpEOCheck.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.grpEOCheck.ForeColor = System.Drawing.Color.Black;
            this.grpEOCheck.Location = new System.Drawing.Point(844, 115);
            this.grpEOCheck.Name = "grpEOCheck";
            this.grpEOCheck.Size = new System.Drawing.Size(210, 70);
            this.grpEOCheck.TabIndex = 94;
            this.grpEOCheck.Text = "EO 적용";
            // 
            // btnNewEO
            // 
            this.btnNewEO.BackColor = System.Drawing.Color.Transparent;
            this.btnNewEO.BorderColor = System.Drawing.Color.Silver;
            this.btnNewEO.BorderRadius = 8;
            this.btnNewEO.BorderThickness = 1;
            this.btnNewEO.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnNewEO.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnNewEO.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnNewEO.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnNewEO.Enabled = false;
            this.btnNewEO.FillColor = System.Drawing.SystemColors.ControlLight;
            this.btnNewEO.FocusedColor = System.Drawing.SystemColors.ControlDark;
            this.btnNewEO.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewEO.ForeColor = System.Drawing.Color.Blue;
            this.btnNewEO.Location = new System.Drawing.Point(9, 33);
            this.btnNewEO.Name = "btnNewEO";
            this.btnNewEO.Size = new System.Drawing.Size(60, 29);
            this.btnNewEO.TabIndex = 149;
            this.btnNewEO.Text = "신규";
            this.btnNewEO.Click += new System.EventHandler(this.btnNewEO_Click);
            // 
            // btnEOPCB
            // 
            this.btnEOPCB.BackColor = System.Drawing.Color.Transparent;
            this.btnEOPCB.BorderColor = System.Drawing.Color.Silver;
            this.btnEOPCB.BorderRadius = 8;
            this.btnEOPCB.BorderThickness = 1;
            this.btnEOPCB.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnEOPCB.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnEOPCB.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnEOPCB.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnEOPCB.FillColor = System.Drawing.SystemColors.ControlLight;
            this.btnEOPCB.FocusedColor = System.Drawing.SystemColors.ControlDark;
            this.btnEOPCB.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnEOPCB.ForeColor = System.Drawing.Color.Black;
            this.btnEOPCB.Location = new System.Drawing.Point(75, 33);
            this.btnEOPCB.Name = "btnEOPCB";
            this.btnEOPCB.Size = new System.Drawing.Size(60, 29);
            this.btnEOPCB.TabIndex = 148;
            this.btnEOPCB.Text = "PCB";
            this.btnEOPCB.Click += new System.EventHandler(this.btnEOPCB_Click);
            // 
            // btnEOContents
            // 
            this.btnEOContents.BackColor = System.Drawing.Color.Transparent;
            this.btnEOContents.BorderColor = System.Drawing.Color.Silver;
            this.btnEOContents.BorderRadius = 8;
            this.btnEOContents.BorderThickness = 1;
            this.btnEOContents.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnEOContents.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnEOContents.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnEOContents.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnEOContents.FillColor = System.Drawing.SystemColors.ControlLight;
            this.btnEOContents.FocusedColor = System.Drawing.SystemColors.ControlDark;
            this.btnEOContents.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnEOContents.ForeColor = System.Drawing.Color.Black;
            this.btnEOContents.Location = new System.Drawing.Point(141, 33);
            this.btnEOContents.Name = "btnEOContents";
            this.btnEOContents.Size = new System.Drawing.Size(60, 29);
            this.btnEOContents.TabIndex = 147;
            this.btnEOContents.Text = "내용";
            this.btnEOContents.Click += new System.EventHandler(this.btnEOSearch_Click);
            // 
            // grpDgvFilter
            // 
            this.grpDgvFilter.BorderRadius = 8;
            this.grpDgvFilter.Controls.Add(this.guna2CheckBox1);
            this.grpDgvFilter.CustomBorderColor = System.Drawing.SystemColors.ActiveCaption;
            this.grpDgvFilter.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.grpDgvFilter.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.grpDgvFilter.ForeColor = System.Drawing.Color.Black;
            this.grpDgvFilter.Location = new System.Drawing.Point(472, 115);
            this.grpDgvFilter.Name = "grpDgvFilter";
            this.grpDgvFilter.Size = new System.Drawing.Size(150, 70);
            this.grpDgvFilter.TabIndex = 93;
            this.grpDgvFilter.Text = "필터";
            this.grpDgvFilter.Visible = false;
            // 
            // guna2CheckBox1
            // 
            this.guna2CheckBox1.AutoSize = true;
            this.guna2CheckBox1.Checked = true;
            this.guna2CheckBox1.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox1.CheckedState.BorderRadius = 0;
            this.guna2CheckBox1.CheckedState.BorderThickness = 0;
            this.guna2CheckBox1.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.guna2CheckBox1.Enabled = false;
            this.guna2CheckBox1.Location = new System.Drawing.Point(10, 43);
            this.guna2CheckBox1.Name = "guna2CheckBox1";
            this.guna2CheckBox1.Size = new System.Drawing.Size(77, 19);
            this.guna2CheckBox1.TabIndex = 0;
            this.guna2CheckBox1.Text = "예약 보기";
            this.guna2CheckBox1.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox1.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox1.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox1.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // pnMain
            // 
            this.pnMain.BorderColor = System.Drawing.Color.White;
            this.pnMain.BorderThickness = 1;
            this.pnMain.Controls.Add(this.dgvMain);
            this.pnMain.Location = new System.Drawing.Point(443, 279);
            this.pnMain.Name = "pnMain";
            this.pnMain.Size = new System.Drawing.Size(320, 242);
            this.pnMain.TabIndex = 95;
            this.pnMain.VisibleChanged += new System.EventHandler(this.pnMain_VisibleChanged);
            // 
            // pnSelect
            // 
            this.pnSelect.BorderColor = System.Drawing.Color.White;
            this.pnSelect.Controls.Add(this.dgvSelect);
            this.pnSelect.Location = new System.Drawing.Point(93, 279);
            this.pnSelect.Name = "pnSelect";
            this.pnSelect.Size = new System.Drawing.Size(298, 242);
            this.pnSelect.TabIndex = 96;
            // 
            // MainForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1280, 1044);
            this.Controls.Add(this.pnSelect);
            this.Controls.Add(this.pnMain);
            this.Controls.Add(this.grpDgvFilter);
            this.Controls.Add(this.grpEOCheck);
            this.Controls.Add(this.grpProduct);
            this.Controls.Add(this.grpShipment);
            this.Controls.Add(this.lblUserName);
            this.Controls.Add(this.pnFpiCheck);
            this.Controls.Add(this.guna2Panel4);
            this.Controls.Add(this.guna2Panel3);
            this.Controls.Add(this.guna2Panel2);
            this.Controls.Add(this.guna2Panel1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.pnTitle);
            this.Controls.Add(this.BtnProductUpdate);
            this.Controls.Add(this.cbbProductName);
            this.Controls.Add(this.cbbLineName);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "MainForm";
            this.Activated += new System.EventHandler(this.MainForm_Activated);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.MainForm_KeyDown);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.MainForm_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.MainForm_MouseMove);
            this.Resize += new System.EventHandler(this.MainForm_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSelect)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnTitle.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.guna2Panel1.ResumeLayout(false);
            this.guna2Panel2.ResumeLayout(false);
            this.guna2Panel3.ResumeLayout(false);
            this.guna2Panel4.ResumeLayout(false);
            this.pnShipmentView.ResumeLayout(false);
            this.pnFpiCheck.ResumeLayout(false);
            this.grpShipment.ResumeLayout(false);
            this.grpProduct.ResumeLayout(false);
            this.grpEOCheck.ResumeLayout(false);
            this.grpDgvFilter.ResumeLayout(false);
            this.grpDgvFilter.PerformLayout();
            this.pnMain.ResumeLayout(false);
            this.pnSelect.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvSelect;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.DataGridView dgvMain;
        private System.Windows.Forms.Label lblUserName;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Timer timer3;
        private Guna.UI2.WinForms.Guna2ComboBox cbbLineName;
        private Guna.UI2.WinForms.Guna2ComboBox cbbProductName;
        private Guna.UI2.WinForms.Guna2Button BtnProductUpdate;
        private Guna.UI2.WinForms.Guna2DragControl guna2DragControl1;
        private Guna.UI2.WinForms.Guna2Button btnProductSearch;
        private Guna.UI2.WinForms.Guna2Button btnProductAdd;
        private Guna.UI2.WinForms.Guna2Button btnProductDelete;
        private System.Windows.Forms.Panel pnTitle;
        private Guna.UI2.WinForms.Guna2TextBox txtMenuAllSearch;
        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox3;
        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox2;
        private Guna.UI2.WinForms.Guna2ControlBox ctbMin;
        private System.Windows.Forms.Label lblFormTitle;
        private System.Windows.Forms.Label lblTopDeco;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 파일ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 로그인ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 로그아웃ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 사용자등록ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 업데이트ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem 종료ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 도움말HToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 업데이트내역ToolStripMenuItem;
        private Guna.UI2.WinForms.Guna2Button btnShipmentChange;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private System.Windows.Forms.Label lblLine;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private System.Windows.Forms.Label lblProduct;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel3;
        private System.Windows.Forms.Label lblDB;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel4;
        private System.Windows.Forms.Label lblDBUpTime;
        private Guna.UI2.WinForms.Guna2Panel pnShipmentView;
        private System.Windows.Forms.Label lblShipmentView;
        private Guna.UI2.WinForms.Guna2BorderlessForm guna2BorderlessForm1;
        private Guna.UI2.WinForms.Guna2Button btnShipmentMaster;
        private Guna.UI2.WinForms.Guna2Panel pnFpiCheck;
        private System.Windows.Forms.Label lblFpiCheck;
        private System.Windows.Forms.ToolStripMenuItem 실험실ToolStripMenuItem;
        private Guna.UI2.WinForms.Guna2GroupBox grpProduct;
        private Guna.UI2.WinForms.Guna2GroupBox grpShipment;
        private Guna.UI2.WinForms.Guna2GroupBox grpEOCheck;
        private Guna.UI2.WinForms.Guna2Button btnEOContents;
        private Guna.UI2.WinForms.Guna2Button btnEOPCB;
        private Guna.UI2.WinForms.Guna2GroupBox grpDgvFilter;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox1;
        private Guna.UI2.WinForms.Guna2Button btnNewEO;
        private Guna.UI2.WinForms.Guna2Panel pnMain;
        private Guna.UI2.WinForms.Guna2Panel pnSelect;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn guest_eo_contents;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column22;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewLinkColumn Column15;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column18;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column19;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column21;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column25;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn select_eo_contents;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column23;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewLinkColumn Column14;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column16;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column17;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column20;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column24;
    }
}

